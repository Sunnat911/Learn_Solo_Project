package uz.pdp.sololearnuzversion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SololearnUzVersionApplicationTests {

    @Test
    void contextLoads() {
    }

}
