package uz.pdp.sololearnuzversion.entity.role;

public enum RoleEnum {
    USER,
    ADMIN,
    SUPER_ADMIN
}
