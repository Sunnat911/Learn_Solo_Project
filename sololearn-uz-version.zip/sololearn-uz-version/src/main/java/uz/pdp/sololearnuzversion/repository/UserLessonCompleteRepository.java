package uz.pdp.sololearnuzversion.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.sololearnuzversion.entity.course.lesson.UserLessonCompleteEntity;

public interface UserLessonCompleteRepository extends JpaRepository<UserLessonCompleteEntity,Long> {
    UserLessonCompleteEntity findByUserId(long userId);
}
