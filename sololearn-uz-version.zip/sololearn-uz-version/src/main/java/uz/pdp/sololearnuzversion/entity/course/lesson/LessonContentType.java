package uz.pdp.sololearnuzversion.entity.course.lesson;

public enum LessonContentType {
    IMAGE,
    TEXT
}
