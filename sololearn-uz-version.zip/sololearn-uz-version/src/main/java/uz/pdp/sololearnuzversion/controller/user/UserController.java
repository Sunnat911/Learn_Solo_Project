package uz.pdp.sololearnuzversion.controller.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.pdp.sololearnuzversion.controller.base.BaseController;
import uz.pdp.sololearnuzversion.model.receive.UserSignInReceiveModel;
import uz.pdp.sololearnuzversion.model.receive.UserSignUpReceiveModel;
import uz.pdp.sololearnuzversion.service.user.UserService;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/sololearn/user")
public class UserController implements BaseController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public HttpEntity<?> addUser(@Valid @RequestBody UserSignUpReceiveModel userSignUpReceiveModel){
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.addUser(userSignUpReceiveModel));
    }

    @PostMapping("/login")
    public HttpEntity<?> login(@Valid @RequestBody UserSignInReceiveModel userSignInReceiveModel){
        return ResponseEntity.ok(userService.login(userSignInReceiveModel));
    }

}
