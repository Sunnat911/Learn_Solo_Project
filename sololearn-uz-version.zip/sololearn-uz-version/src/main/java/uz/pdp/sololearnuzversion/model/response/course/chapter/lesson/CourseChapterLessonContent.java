package uz.pdp.sololearnuzversion.model.response.course.chapter.lesson;

import lombok.Data;

@Data
public class CourseChapterLessonContent {
    private String text;
    private String url;
}
