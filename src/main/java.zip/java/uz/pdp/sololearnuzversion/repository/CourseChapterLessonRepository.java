package uz.pdp.sololearnuzversion.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.pdp.sololearnuzversion.entity.course.lesson.CourseChapterLessonEntity;

import java.util.List;

public interface CourseChapterLessonRepository extends JpaRepository<CourseChapterLessonEntity,Long> {
    List<CourseChapterLessonEntity> findByCourseChapterEntityId(long courseChapterId);
}
