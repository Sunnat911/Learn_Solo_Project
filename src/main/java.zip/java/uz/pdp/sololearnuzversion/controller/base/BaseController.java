package uz.pdp.sololearnuzversion.controller.base;

import uz.pdp.sololearnuzversion.model.response.ApiResponse;

public interface BaseController {

}
