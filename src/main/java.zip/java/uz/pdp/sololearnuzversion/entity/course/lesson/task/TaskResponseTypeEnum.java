package uz.pdp.sololearnuzversion.entity.course.lesson.task;

public enum TaskResponseTypeEnum {
    CHECK, // masalan 4 tadan 2 tasi to'g'ri bolishi mm
    TEST,
    SORT,
    INPUT
}
